<?php
return array (
  'danmuon' => '0',
  'color' => '#24a5ff',
  'logo' => 'https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d83be038-d395-4d8c-b3b6-f74c025473f7/0238edc1-4ee6-4795-91bc-6db829f0d3ca.png',
  'trytime' => '3',
  'waittime' => '10',
  'sendtime' => '10',
  'pbgjz' => '草,操,妈,逼,滚,网址,网站,关注,wx,微信,qq,QQ,百度,搜索,公众号,看片,习近平,法轮,迫害,翻墙',
  'user' => 'NULL',
  'state' => '1',
  'ads' => 
  array (
    'pic' => 
    array (
      'time' => '6',
      'img' => 'https://m.ykimg.com/material/0A03/A1/202204/0426/3063067/1650981163721/0D0100006267FD861861622399395632.jpg',
      'link' => '#',
    ),
    'vod' => 
    array (
      'time' => 'https://storage.googleapis.com/img.cjgxs10.cc/media/common/2021/0912/24e024bcd605ff820c556c714476e018.mp4',
      'link' => '#',
    ),
    'pause' => 
    array (
      'state' => 'on',
      'img' => 'https://m.ykimg.com/material/0A03/A1/202204/0426/3063067/1650981163721/0D0100006267FD861861622399395632.jpg',
      'link' => '#',
    ),
  ),
  'gx' => 
  array (
    'pic' => 'https://img10.360buyimg.com/ddimg/jfs/t1/176340/18/8164/733759/609395e4E2df09db0/80b3d377da26e626.jpg',
    'load_icon' => '0',
    'load_img' => '',
    'load_color' => '#00a1d6',
    'logo' => '1',
    'logo_val' => 'right: 5%;top: 5%;',
  ),
  'color_f' => '#DC143C	',
  'chinese' => '2',
  'audit' => '0',
  'user_danmuon' => '0',
  'random_img' => 'https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d83be038-d395-4d8c-b3b6-f74c025473f7/3df0fa63-1ffa-43a4-a2ff-5b1e229aec8f.jpg#https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d83be038-d395-4d8c-b3b6-f74c025473f7/6399b3db-e1c7-401c-be6c-0a5b1cef80a2.jpg#https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d83be038-d395-4d8c-b3b6-f74c025473f7/c9528812-5c8c-404a-8fcd-f65dd85758e8.jpg#https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d83be038-d395-4d8c-b3b6-f74c025473f7/7759ca84-2c6a-4fef-881b-bb9e4c270114.jpg#https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d83be038-d395-4d8c-b3b6-f74c025473f7/e4f3d020-003b-4ad7-9ed1-bae92aab0743.jpg#https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d83be038-d395-4d8c-b3b6-f74c025473f7/17c6ea72-da4a-4ee9-94d5-674b480c037b.jpg#https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d83be038-d395-4d8c-b3b6-f74c025473f7/eb72590d-37e4-4e79-9d60-9341576ead0a.jpg#https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d83be038-d395-4d8c-b3b6-f74c025473f7/820a1e17-b76b-4dcd-81cb-d2f453a911e1.jpg',
  'random' => '1',
  'marquee' => '欢迎访问祝你观影愉快',
  'key' => '5D9A2A9FA39038F9',
  'iv' => '1E24CF708A14CE81',
  'tga' => '',
  'cache' => '0',
  'length' => '30',
  'try-user' => 'NULL',
  'force' => '1',
  'handle' => '0',
  'mode' => '0',
  'host' => 'http://127.0.0.1/',
  'default' => '0',
  'play-type' => 'dp',
  'yuan' => '',
  'api' => 'youku,qq,iqiyi$https://111.com/json.php?url=||0||15||30||0||0||0#qq$https://333.com/json.php?url=||0||15||30||0||0||0#youku,iqiyi,qq$https://11555.com/json.php?url=||0||15||30||0||0||0#ltnb,renrenmi$http://127.0.0.1?url=||3600||15||30||0||0||0',
  'jx' => 
  array (
    'youku' => 
    array (
      0 => 'https://111.com/json.php?url=||0||15||30||0||0||0',
      1 => 'https://11555.com/json.php?url=||0||15||30||0||0||0',
    ),
    'qq' => 
    array (
      0 => 'https://111.com/json.php?url=||0||15||30||0||0||0',
      1 => 'https://333.com/json.php?url=||0||15||30||0||0||0',
      2 => 'https://11555.com/json.php?url=||0||15||30||0||0||0',
    ),
    'iqiyi' => 
    array (
      0 => 'https://111.com/json.php?url=||0||15||30||0||0||0',
      1 => 'https://11555.com/json.php?url=||0||15||30||0||0||0',
    ),
    'ltnb' => 
    array (
      0 => 'http://127.0.0.1?url=||3600||15||30||0||0||0',
    ),
    'renrenmi' => 
    array (
      0 => 'http://127.0.0.1?url=||3600||15||30||0||0||0',
    ),
  ),
);